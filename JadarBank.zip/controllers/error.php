<?php

    class Errorr {
        function __construct(){
            echo "<p>Error al cargar el recurso</p>";
        }
    }

?>