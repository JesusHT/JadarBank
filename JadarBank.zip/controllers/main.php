<?php

    class Main {
        function __construct(){
            echo "<p>Nuevo controlador</p>";
        }

        function saludo(){
            echo '<p>Ejecutaste el metodo saludo</p>';
        }
    }

?>